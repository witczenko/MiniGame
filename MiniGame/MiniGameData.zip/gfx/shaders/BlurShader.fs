#version 130

precision mediump float;

out vec4 color;
in vec2 uv;
in vec2 v_blurTexCoords[5];
//Game Time 
uniform float iGlobalTime;

//Texture 
uniform sampler2D textureSampler;


void main(void){	
	//color = texture( textureSampler, uv );
    color = vec4(0.0);
    color += texture2D(textureSampler, v_blurTexCoords[0]) * 0.204164;
    color += texture2D(textureSampler, v_blurTexCoords[1]) * 0.304005;
    color += texture2D(textureSampler, v_blurTexCoords[2]) * 0.304005;
    color += texture2D(textureSampler, v_blurTexCoords[3]) * 0.093913;
    color += texture2D(textureSampler, v_blurTexCoords[4]) * 0.093913;
}