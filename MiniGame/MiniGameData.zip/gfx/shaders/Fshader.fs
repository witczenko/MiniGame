#version 130

precision mediump float;

out vec4 color;
in vec2 uv;

//Game Time 
uniform float iGlobalTime;

//Texture 
uniform sampler2D textureSampler;


void main(void){
	vec4 texel = texture( textureSampler, uv );
	if(texel.a < 0.6)
    discard;
	color = texel;
}